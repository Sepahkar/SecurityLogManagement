import requests
from .utils import APIClient
from .endpoints import *

_IsSuccessfull = bool
_StatusCode = bool


def _check_eit_in_username(username):
    if not "@eit" in username:
        raise Exception("@eit must be in username")


class v1:
    # _________________________HR___________________________
    @staticmethod
    def get_user(username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        _check_eit_in_username(username)

        url = f'{V1_HR_GET_USER}{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")

    @staticmethod
    def get_user_more_detail(username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        _check_eit_in_username(username)

        url = f'{V1_HR_USER_MORE_DETAIL}{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json()[0]  
    
    @staticmethod
    def nationalcode2username(national_code:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, str]:
        url = f'{V1_HR_USER_IDENTITY_CONVERTOR}'
        params.update({"national_code":national_code})
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("UserName")  
    
    
    @staticmethod
    def get_user_roles(username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        _check_eit_in_username(username)

        url = f'{V1_HR_GET_USER_ROLES}{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data") 
    

    @staticmethod
    def get_all_users(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_HR_GET_ALL_USERS}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data") 

    @staticmethod
    def get_all_user_team_roles(username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        _check_eit_in_username(username)

        url = f'{V1_HR_USER_ALL_TEAM_ROLES}{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")

    @staticmethod
    def teams(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_HR_TEAMS}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json()
    
    @staticmethod
    def get_team(teamcode:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_HR_TEAMS}{teamcode}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json()[0]

    @staticmethod
    def roles(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_HR_ROLES}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json() 
    
    @staticmethod
    def get_role(role_id:int, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_HR_ROLES}{role_id}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json()[0]
    
    # _________________________AccessControl___________________________
    @staticmethod
    def get_all_apps_url(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_ACCESSCONTROL_GET_ALL_APPS_URL}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")

    @staticmethod
    def get_all_apps_info(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list|dict]:
        url = f'{V1_ACCESSCONTROL_GET_ALL_APPS_INFO}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")  
    
    @staticmethod
    def get_app_by_appcode(appcode:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list|dict]:
        url = f'{V1_ACCESSCONTROL_GET_APP_BY_APPCODE}{appcode}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")  
    
    @staticmethod
    def get_user_urls(app_label:str, username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list|dict]:
        _check_eit_in_username(username)
        
        url = f'{V1_ACCESSCONTROL_GET_USER_URLS}{app_label}/{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    
    @staticmethod
    def get_app_url(app_url_id:int, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_ACCESSCONTROL_GET_APP_URL}{app_url_id}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")

    @staticmethod
    def get_system(system_code:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_ACCESSCONTROL_GET_SYSTEM}{system_code}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    
    @staticmethod
    def get_server(server_id:int, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_ACCESSCONTROL_GET_SERVER}{server_id}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    
    @staticmethod
    def get_user_all_urls(username:str, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = f'{V1_ACCESSCONTROL_GET_USER_ALL_URLS}{username}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")

    @staticmethod
    def apps(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_ACCESSCONTROL_GET_ALL_APPS}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    
    @staticmethod
    def systems(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_ACCESSCONTROL_GET_ALL_SYSTEMS}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    
    @staticmethod
    def servers(*, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, list]:
        url = f'{V1_ACCESSCONTROL_GET_ALL_SERVERS}'
        response = api_client.get(url, params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, response.json().get("data")
    

    # _________________________Notification___________________________
    @staticmethod
    def send_template_mail_notif(template_code:str, variables:dict={}, *, params={}, api_client: APIClient) -> tuple[_IsSuccessfull, _StatusCode, dict]:
        url = V1_NOTIFICATION_SEND_TEMPLATE_EMAIL
        response = api_client.post(
            url,
            json={
                "template_code":template_code,
                "variables":variables
            },
            params=params)  
        try: 
            response.raise_for_status()
        except requests.HTTPError:
            return False, response.status_code, response.json()  
        return True, response.status_code, None

    