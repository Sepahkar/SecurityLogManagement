import requests
from requests import Session
from . import core


def new_api_client(request):
    actual_user = None
    user = None

    if hasattr(request, "actual_user"):
        actual_user = request.actual_user.username
    if hasattr(request, "user"):
        user = request.user.username
    
    if not (actual_user or user):
        # if this happens, you have to find the related bug in auth2 mechanisim
        # technically this never happens
        raise 
    
    return APIClient(delegated_by=user,actual_user=actual_user)

class APIClient:
    def __init__(self, delegated_by:str, **kwargs):
        actual_user:str = kwargs.get("actual_user")
        self.session:Session = requests.Session()
        self.session.headers.update(
            {
                "Service-Authorization": core.generate_token(username=delegated_by, expire_seconds=60),
                "Content-Type": "application/json"
            }
        )
        if actual_user and actual_user.lower()!=delegated_by.lower():
            self.session.headers.update(
                {
                "Impersonate-Username": core.generate_token(username=actual_user, expire_seconds=60),
                }
            )
    
    def get(self, url:str, **kwargs):
        response = self.session.get(url, **kwargs)
        response.raise_for_status()
        return response

    def post(self, url:str, **kwargs):
        response = self.session.post(url, **kwargs)
        response.raise_for_status()
        return response
    
    def put(self, url:str, **kwargs):
        response = self.session.put(url, **kwargs)
        response.raise_for_status()
        return response
    
    def patch(self, url:str, **kwargs):
        response = self.session.patch(url, **kwargs)
        response.raise_for_status()
        return response
    
    def delete(self, url:str, **kwargs):
        response = self.session.delete(url, **kwargs)
        response.raise_for_status()
        return response
    
    def head(self, url:str, **kwargs):
        response = self.session.head(url, **kwargs)
        response.raise_for_status()
        return response

    def options(self, url:str, **kwargs):
        response = self.session.options(url, **kwargs)
        response.raise_for_status()
        return response