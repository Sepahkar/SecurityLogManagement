import os 

def _add_scheme_host(port, uri):
    host = os.getenv("HOST", None)
    if not host:
        # make sure you have HOST env variable on you .env file 
        raise
    return f"{host}:{port}{uri}"

_P_HR = "14000"
_P_ACCESSCONTROL = "13000"
_P_NOTIFICATION = "6000"

# *************************
# HR Services endpoints
# *************************
V1_HR_ROLES=_add_scheme_host(_P_HR, "/HR/api/v1/roles/")
V1_HR_TEAMS=_add_scheme_host(_P_HR, "/HR/api/v1/teams/")
V1_HR_GET_USER = _add_scheme_host(_P_HR, "/HR/api/get-user/")
V1_HR_USER_MORE_DETAIL = _add_scheme_host(_P_HR, "/HR/api/v1/users/")
V1_HR_GET_USER_ROLES = _add_scheme_host(_P_HR, "/HR/api/get-user-roles/")
V1_HR_GET_ALL_USERS = _add_scheme_host(_P_HR, "/HR/api/all-users/")
V1_HR_USER_ALL_TEAM_ROLES=_add_scheme_host(_P_HR, "/HR/api/get-user-all-team-role/")
V1_HR_USER_IDENTITY_CONVERTOR=_add_scheme_host(_P_HR, "/HR/api/user-identity-convertor/")



# *************************
# AcceseControl Services endpoints
# *************************
V1_ACCESSCONTROL_GET_ALL_APPS_URL = _add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-all-apps-url/")
V1_ACCESSCONTROL_GET_ALL_APPS_INFO = _add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-all-apps-info/")
V1_ACCESSCONTROL_GET_APP_BY_APPCODE = _add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-app-by-appcode/")
V1_ACCESSCONTROL_GET_USER_URLS = _add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-user-urls/")
V1_ACCESSCONTROL_GET_APP_URL=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-app-url/")
V1_ACCESSCONTROL_GET_SYSTEM=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-system/")
V1_ACCESSCONTROL_GET_SERVER=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-server/")
V1_ACCESSCONTROL_GET_USER_ALL_URLS=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-user-all-urls/")
V1_ACCESSCONTROL_GET_ALL_APPS=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-apps/")
V1_ACCESSCONTROL_GET_ALL_SYSTEMS=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-all-systems/")
V1_ACCESSCONTROL_GET_ALL_SERVERS=_add_scheme_host(_P_ACCESSCONTROL, "/AccessControl/api/get-all-servers/")


# *************************
# Notification Services endpoints
# *************************
V1_NOTIFICATION_SEND_TEMPLATE_EMAIL=_add_scheme_host(_P_NOTIFICATION, "/EmailService/api/v1/send-template-mail/")


