module.exports = {
  content: ['./docs/**/*.{html,js,ts}', './src/**/*.{js,ts}'],
  theme: {
    extend: {},
  },
  plugins: [],
};

